#ifndef __EDMP_PERSON_H__
#define __EDMP_PERSON_H__
#include <edmp-const.h>

typedef struct {
	char edmpId    [LEN_EDMP_ID + 1 ];
	char imsiNum   [LEN_IMSI_NUM + 1 ];
	char mdn       [LEN_MDN + 1 ];
	char svcMgmtNum[LEN_SVC_MGMT_NUM + 1];
} s_edmpPerson; 


int edmpGetPerson   (s_edmpPersonIn *in,    s_edmpPersonOut *out);

#endif   //__EDMP_PERSON_H__
