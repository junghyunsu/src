#ifndef __EDMP_CONST_H__
#define __EDMP_CONST_H__

#define TRUE 1
#define FALSE 0

#define LEN_SVC_MGMT_NUM 32
#define LEN_EDMP_ID      32
#define LEN_IMSI_NUM     32
#define LEN_MDN     32 

#define MAX_AD_COUNT 64

#endif   //__EDMP_CONST_H__
