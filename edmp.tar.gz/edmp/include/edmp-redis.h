#ifndef __EDMP_REDIS_H__
#define __EDMP_REDIS_H__
#include <hiredis.h>

#define EDMP_REDIS_SET_STR "SET key:%s %s"
#define EDMP_REDIS_GET_STR "GET key:%s"

redisContext* edmpRedisGetContext(void);
redisReply*   edmpRedisSet       (redisContext* c,  char *key, char *value);
redisReply*   edmpRedisGet       (redisContext* c,  char *key);

#endif   //__EDMP_REDIS_H__
