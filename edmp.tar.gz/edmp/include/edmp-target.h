#ifndef __EDMP_TARGET_H__
#define __EDMP_TARGET_H__
#include <edmp-const.h>

#define TARGET_NONE         0
#define TARGET_GENDER       1
#define TARGET_AGE          2
#define TARGET_LOCATION     3
#define TARGET_ACT_LOCATION 4
#define TARGET_INTEREST     5

typedef struct {
	char svcMgmtNum[LEN_SVC_MGMT_NUM + 1];
	int  adId;
} s_edmpTargetIn; 

typedef struct {
	int adId;
	int isTargeted;
	int targetType;
} s_edmpTargetOut;

typedef struct {
	char svcMgmtNum[LEN_SVC_MGMT_NUM + 1];
	int  adId       [MAX_AD_COUNT];
} s_edmpTargetInArr; 

typedef struct {
	int adId      [MAX_AD_COUNT];
	int isTargeted[MAX_AD_COUNT];
	int targetType[MAX_AD_COUNT];
} s_edmpTargetOutArr;

typedef struct {
	char svcMgmtNum[LEN_SVC_MGMT_NUM + 1];
	int  targetType;
	/* 향후 추가 필요 */ 
} s_edmpTargetProfile; 

int edmpGetTarget   (s_edmpTargetIn *in,    s_edmpTargetOut *out);
int edmpGetTargetArr(s_edmpTargetInArr *in, s_edmpTargetOutArr *out);

#endif   //__EDMP_TARGET_H__
