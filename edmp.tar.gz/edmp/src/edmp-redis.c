#include <edmp-redis.h>
#include <edmp-redis-const.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

redisContext *g_redisContext = NULL;


// Static function definition
static redisContext * edmpRedisConnect(void);


/*---------------------------------------
 * edmpRedisGetContext
 * --------------------------------------*/
redisContext* edmpRedisGetContext(void) {
	// 향후 connction pool로 변경해야 함
	if ( g_redisContext != NULL ) {
		return g_redisContext; 
	}
	
	g_redisContext = edmpRedisConnect(); 
	return g_redisContext;
}


/*---------------------------------------
 * Redis Connect
 * --------------------------------------*/
static redisContext * edmpRedisConnect(void) {
	struct timeval timeout = { 1, 500000 }; // 1.5 seconds
	redisContext *c = redisConnectWithTimeout("50.1.102.91", 6379, timeout);
	if ( c == NULL ) {
		printf("Error: redisContext NULi!\n");
		return NULL;
	}

	if ( c != NULL && c->err) {
		printf("Error: %s\n", c->errstr);
		return NULL;
    }
	printf("Coonect success![%d] \n", c->err);

	return c;
}


/* Description : Redis get */
redisReply * edmpRedisSet(redisContext* c, char *key, char *value) {
	redisReply *reply;

	if( c == NULL )	 {
		printf("Invalid context(NULL)!");
		return NULL;
	}

	reply = redisCommand(c, EDMP_REDIS_SET_STR, key, value);

	if( reply == NULL ) {
		printf("redisCommmand reply NULL, [%s]\n", c->errstr);
	}	
	if( reply->type == REDIS_REPLY_ERROR ) {
		printf("redisCommmand reply error, [%s]\n", reply->str);
		freeReplyObject(reply);	
		return NULL;
	}

	return reply;
}


/* Redis Get */
redisReply * edmpRedisGet(redisContext* c, char *key) {
	redisReply *reply;

	if( c == NULL )	 {
		printf("Invalid context(NULL)!");
		return NULL;
	}

	reply = redisCommand(c, EDMP_REDIS_GET_STR, key);

	if( reply == NULL ) {
		printf("redisCommmand reply NULL, [%s]\n", c->errstr);
		return NULL;
	}

	if( reply->type == REDIS_REPLY_ERROR ) {
		printf("redisCommmand reply error, [%s]\n", reply->str);
		freeReplyObject(reply);	
		return NULL;
	}
	else if( reply->type == REDIS_REPLY_NIL ) {
		printf("No data key[%s]\n", key);
		return NULL;
	}

	return reply;
}

#if 0
int main(int argc, char *argv[]) {
	redisReply *reply;

	char key[1024],  value[1024]; 
		
	c = edmpRedisConnect();
	if( c  == NULL ) {
		return -1;
	}
	
	strcpy(key,   "foo");
	strcpy(value, "bar");

	reply = (redisReply*) edmpRedisSet(c, key, value);
	if( reply == NULL ) {
		return -1;
	}

	reply = (redisReply*) edmpRedisGet(c, key);
	if( reply == NULL ) {
		return -1;
	}

	printf("key[%s] value[%.*s]\n", key, reply->len, reply->str);
	
	freeReplyObject(reply);	
	return 0;
}

#endif
