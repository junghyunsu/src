#include <edmp-redis.h>
#include <edmp-const.h>
#include <edmp-target.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

// static function
static void                  setTargetOut(int adId, int isTargeted, int targetType, s_edmpTargetOut *out);
static s_edmpTargetProfile * getTargetProfile(char *svcMgmtNum);

/*---------------------------------------
 * edmp_get_target
 * --------------------------------------*/
int edmpGetTarget(s_edmpTargetIn *in, s_edmpTargetOut *out) {
	s_edmpTargetProfile *tp;

	/* Input check */
	if( in == NULL || out == NULL) {
		printf("NULL parameter value.\n");
		return -1;
	}

	tp = getTargetProfile(in->svcMgmtNum);
	if( tp == NULL ) {
		setTargetOut(in->adId, FALSE, TARGET_NONE, out);
		return -1;
	}

	/* targeting algorithm 구현 필요 */
	setTargetOut(in->adId, TRUE, TARGET_AGE, out);
	return 0;	
}

/*
 * edmpGetTargetArr()
 */
int edmpGetTargetArr(s_edmpTargetInArr *in, s_edmpTargetOutArr *out) {
	/* 향후 구현 필요 */

	return 1;
}

/*
 * setTargetOut
 * */
static void setTargetOut(int adId, int isTargeted, int targetType, s_edmpTargetOut *out) {
		out->adId       = adId;
		out->isTargeted = isTargeted;
		out->targetType = targetType;

		return;
}


static s_edmpTargetProfile *getTargetProfile(char *svcMgmtNum) {
	/* 향후 Redis 연동하여 data 가져 와야 함 */
	redisContext *c;
	s_edmpTargetProfile *tp;
	redisReply *reply;

	/* Redis 연결 */ 
	c = edmpRedisGetContext();
	if( c == NULL )
		return NULL;

	reply = edmpRedisGet(c, svcMgmtNum);
	if( reply == NULL ) {
		return NULL;
	}

	tp = malloc(sizeof(s_edmpTargetProfile));
	if( tp == NULL ) {
		printf("malloc fail! errno[%d][%s]\n", errno, strerror(errno));
		return NULL;
	}

	memcpy(tp->svcMgmtNum, svcMgmtNum, LEN_SVC_MGMT_NUM +1 );
	tp->targetType = TARGET_AGE;
	
	return tp;
} 

#if 0
int main(int argc, char *argv[]) {
	redisContext *c;
	redisReply *reply;

	char key[1024],  value[1024]; 
		
	c = edmpRedisConnect();
	if( c  == NULL ) {
		return -1;
	}
	
	strcpy(key,   "foo");
	strcpy(value, "bar");

	reply = (redisReply*) edmpRedisSet(c, key, value);
	if( reply == NULL ) {
		return -1;
	}

	reply = (redisReply*) edmpRedisGet(c, key);
	if( reply == NULL ) {
		return -1;
	}

	printf("key[%s] value[%.*s]\n", key, reply->len, reply->str);
	
	freeReplyObject(reply);	
	return 0;
}
#endif
