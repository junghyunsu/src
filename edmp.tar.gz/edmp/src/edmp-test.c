#include <edmp_redis.h>
#include <edmp_redis_const.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int main(int argc, char *argv[]) {
	redisReply *reply;

	char key[1024],  value[1024]; 
		
	c = edmpRedisConnect();
	if( c  == NULL ) {
		return -1;
	}
	
	strcpy(key,   "foo");
	strcpy(value, "bar");

	reply = (redisReply*) edmpRedisSet(c, key, value);
	if( reply == NULL ) {
		return -1;
	}

	reply = (redisReply*) edmpRedisGet(c, key);
	if( reply == NULL ) {
		return -1;
	}

	printf("key[%s] value[%.*s]\n", key, reply->len, reply->str);
	
	freeReplyObject(reply);	
	return 0;
}

