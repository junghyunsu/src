#include <edmp-redis.h>
#include <edmp-const.h>
#include <edmp-target.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

// static function
static void                  setPersonOut(int adId, int isPersoned, int targetType, s_edmpPersonOut *out);
static s_edmpPersonProfile * getPersonProfile(char *svcMgmtNum);

/*---------------------------------------
 * edmp_get_target
 * --------------------------------------*/
int edmpGetPerson(s_edmpPersonIn *in, s_edmpPersonOut *out) {
	s_edmpPersonProfile *tp;

	/* Input check */
	if( in == NULL || out == NULL) {
		printf("NULL parameter value.\n");
		return -1;
	}

	tp = getPersonProfile(in->svcMgmtNum);
	if( tp == NULL ) {
		setPersonOut(in->adId, FALSE, TARGET_NONE, out);
		return -1;
	}

	/* targeting algorithm 구현 필요 */
	setPersonOut(in->adId, TRUE, TARGET_AGE, out);
	return 0;	
}


/*
 * setPersonOut
 * */
static void setPersonOut(int adId, int isPersoned, int targetType, s_edmpPersonOut *out) {
		out->adId       = adId;
		out->isPersoned = isPersoned;
		out->targetType = targetType;

		return;
}


static s_edmpPersonProfile *getPersonProfile(char *svcMgmtNum) {
	/* 향후 Redis 연동하여 data 가져 와야 함 */
	redisContext *c;
	s_edmpPersonProfile *tp;
	redisReply *reply;

	/* Redis 연결 */ 
	c = edmpRedisGetContext();
	if( c == NULL )
		return NULL;

	reply = edmpRedisGet(c, svcMgmtNum);
	if( reply == NULL ) {
		return NULL;
	}

	tp = malloc(sizeof(s_edmpPersonProfile));
	if( tp == NULL ) {
		printf("malloc fail! errno[%d][%s]\n", errno, strerror(errno));
		return NULL;
	}

	memcpy(tp->svcMgmtNum, svcMgmtNum, LEN_SVC_MGMT_NUM +1 );
	tp->targetType = TARGET_AGE;
	
	return tp;
} 

#if 0
int main(int argc, char *argv[]) {
	redisContext *c;
	redisReply *reply;

	char key[1024],  value[1024]; 
		
	c = edmpRedisConnect();
	if( c  == NULL ) {
		return -1;
	}
	
	strcpy(key,   "foo");
	strcpy(value, "bar");

	reply = (redisReply*) edmpRedisSet(c, key, value);
	if( reply == NULL ) {
		return -1;
	}

	reply = (redisReply*) edmpRedisGet(c, key);
	if( reply == NULL ) {
		return -1;
	}

	printf("key[%s] value[%.*s]\n", key, reply->len, reply->str);
	
	freeReplyObject(reply);	
	return 0;
}
#endif
